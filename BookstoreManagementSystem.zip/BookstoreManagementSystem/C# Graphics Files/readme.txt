The GUI for the book store database needs configuration before operating.
-- These include:
- Connecting the sql server management studio with VS
- Changing the SQL connection path in the code
- The images used in the GUI may need to be reset too
